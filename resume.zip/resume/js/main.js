$(window).on('load', function(){

    // Vide.js - video backgraund
    $('#header').vide('./video/cover', {
        bgColor: '#64947b'

    })
});